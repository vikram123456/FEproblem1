//
//  Constants.swift
//  FEproblem1
//
//  Created by Thakor Vikramji Kishanji on 10/05/22.
//

import Foundation
import UIKit

public struct Constants{
    
    //MARK: UI Constants
    static let kFont = UIFont(name: "Thonburi", size: 16)
    static let kColorText = UIColor(red: 0.1803921569, green: 0.1803921569, blue: 0.1803921569, alpha: 1)
    static let kColorOrange = UIColor(red: 0.8980392157, green: 0.5843137255, blue: 0.231372549, alpha: 1)
    
    
    //MARK: Messages Constants
    public static let kDefaultErrorMessage = "Something went wrong, Please try again later."
    public static let kNoPlanets = "There is no any planet found.  Please search again."
    public static let kSearchOther = "Please select any planet to find falcone!"

    //MARK: API Constants
    public static let kSuccess = "success"

    public static let windowApp = UIApplication.shared.connectedScenes
            .filter({$0.activationState == .foregroundActive})
            .compactMap({$0 as? UIWindowScene})
            .first?.windows
            .filter({$0.isKeyWindow}).first
    
    //MARK: Other Method
    static func showAlert(_ message : String){
        let alert = UIAlertController(title: "FEproblem", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default))
        windowApp?.rootViewController!.present(alert, animated: true, completion: nil)
    }
}
