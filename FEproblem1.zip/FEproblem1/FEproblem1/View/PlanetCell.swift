//
//  PlanetCell.swift
//  FEproblem1
//
//  Created by Thakor Vikramji Kishanji on 15/05/22.
//

import UIKit

class PlanetCell: UITableViewCell {

    @IBOutlet weak var labelPlanet: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
 
    // MARK: - Cell setup...

    func setupPlanetCell(objPlanet : Planet) {
        self.labelPlanet?.text = objPlanet.name
    }
    

}
