//
//  RadioCell.swift
//  FEproblem1
//
//  Created by Thakor Vikramji Kishanji on 15/05/22.
//

import UIKit

class RadioCell: UITableViewCell {

    @IBOutlet weak var labelRadio: UILabel!
    @IBOutlet weak var buttonRadio: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }


    func setupRadioButtonCell(objVehicle :Vehicle, arrSelectedVehicles : [[String:String]], indexpath: IndexPath){
        
        self.labelRadio?.text = (objVehicle.name ?? "") + " (" + String(objVehicle.total_no ?? 0) + ")"
     
        
        if(arrSelectedVehicles.count > 0){
            let arrChecked = arrSelectedVehicles.filter { $0["section"]!.contains(String(indexpath.section)) }
            for objSelected in arrChecked{
                if indexpath.section == Int(objSelected["section"] ?? "0") &&  objSelected["vehicle"] == objVehicle.name {
                    self.buttonRadio.setImage(UIImage(named: "radio_on"), for: .normal)
                }else{
                    self.buttonRadio.setImage(UIImage(named: "radio_off"), for: .normal)
                }
            }
            if arrChecked.count == 0 {
                self.buttonRadio.setImage(UIImage(named: "radio_off"), for: .normal)
            }
        }else{
            self.buttonRadio.setImage(UIImage(named: "radio_off"), for: .normal)
        }
    }
}
