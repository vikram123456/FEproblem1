//
//  Vehicles.swift
//  FEproblem1
//
//  Created by Thakor Vikramji Kishanji on 15/05/22.
//

import Foundation

struct Vehicle: Codable, Equatable{
    let name : String?
    let total_no : Int?
    let max_distance : Int?
    var speed : Int?
    
    enum CodingKeys : String, CodingKey{
        case name, total_no, max_distance, speed
    }
}
