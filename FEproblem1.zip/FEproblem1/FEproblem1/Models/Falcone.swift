//
//  Falcone.swift
//  FEproblem1
//
//  Created by Thakor Vikramji Kishanji on 16/05/22.
//

import Foundation

struct Falcone : Codable, Equatable{
    let planet_name : String?
    let status : String?
    
    enum CodingKeys : String, CodingKey {
    case planet_name, status
    }
}
