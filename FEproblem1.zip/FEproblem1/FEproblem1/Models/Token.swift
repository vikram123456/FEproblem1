//
//  Token.swift
//  FEproblem1
//
//  Created by Thakor Vikramji Kishanji on 15/05/22.
//

import Foundation

struct Token : Codable{
    let token:  String?
}
