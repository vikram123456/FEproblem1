//
//  Planets.swift
//  FEproblem1
//
//  Created by Thakor Vikramji Kishanji on 14/05/22.
//

import Foundation

 

struct Planets : Codable{
    let arrPlanets : [Planet]?
}

struct Planet : Codable, Equatable{
    let name : String?
    let distance : Int?
    
    enum CodingKeys: String, CodingKey {
    case name, distance
    }
}

