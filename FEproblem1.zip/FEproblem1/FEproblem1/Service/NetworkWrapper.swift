//
//  NetworkWrapper.swift
//  FEproblem1
//
//  Created by Thakor Vikramji Kishanji on 10/05/22.
//

import Foundation

class NetworkWrapper {
    
    enum ErrorType : String{
        case noInternetError =  "No internet connection. Please try again after some time"
        case otherError         =  "We are facing some technical issue. Please try again later"
    }
    
    struct ErrorModel : Error {
        let message : String
        let header : String
        let title : String
        
        init(message : String? = nil, header : String? = nil, title : String? = nil) {
            self.message = message ?? ""
            self.header = header ?? ""
            self.title = title ?? ""
        }
    }
    
    enum HTTPMethod : String {
        case get = "GET"
        case post = "POST"
    }
 
    static func connectForPlanets(httpMethod: HTTPMethod, request : URLRequest, completionHandler:@escaping(Result<[Planet],ErrorModel>) -> Void){
        
        if !Reachability.isConnectedToInternet() {
            let errormodel = ErrorModel(message: ErrorType.noInternetError.rawValue,  title:Constants.kDefaultErrorMessage)
            completionHandler(.failure(errormodel))
        }
        
        var request = request
        request.httpMethod = httpMethod.rawValue
        
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            
            guard let data =  data, error == nil else {
                let error = ErrorModel(message: ErrorType.noInternetError.rawValue, title: Constants.kDefaultErrorMessage)
                completionHandler(.failure(error))
                return
            }
            
            do {
                let res = try JSONDecoder().decode([Planet].self, from: data)
                completionHandler(.success(res))
                return
            } catch  {
                DispatchQueue.main.async {
                    let error = ErrorModel(message: ErrorType.otherError.rawValue, title: Constants.kDefaultErrorMessage)
                    completionHandler(.failure(error))
                }
                return
            }
        }
        task.resume()
    }
    
    static func connectForVehicles(httpMethod: HTTPMethod, request : URLRequest, completionHandler:@escaping(Result<[Vehicle],ErrorModel>) -> Void){
        
        if !Reachability.isConnectedToInternet() {
            let errormodel = ErrorModel(message: ErrorType.noInternetError.rawValue,  title:Constants.kDefaultErrorMessage)
            completionHandler(.failure(errormodel))
        }
        
        var request = request
        request.httpMethod = httpMethod.rawValue
        
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            
            guard let data =  data, error == nil else {
                let error = ErrorModel(message: ErrorType.noInternetError.rawValue, title: Constants.kDefaultErrorMessage)
                completionHandler(.failure(error))
                return
            }
            
            do {
                let res = try JSONDecoder().decode([Vehicle].self, from: data)
                completionHandler(.success(res))
                return
            } catch  {
                DispatchQueue.main.async {
                    let error = ErrorModel(message: ErrorType.otherError.rawValue, title: Constants.kDefaultErrorMessage)
                    completionHandler(.failure(error))
                }
                return
            }
        }
        task.resume()
    }
    
    
    static func findToken(httpMethod: HTTPMethod, request : URLRequest, completionHandler:@escaping(Result<Token,ErrorModel>) -> Void){
        
        if !Reachability.isConnectedToInternet() {
            let errormodel = ErrorModel(message: ErrorType.noInternetError.rawValue,  title:Constants.kDefaultErrorMessage)
            completionHandler(.failure(errormodel))
        }
        
        var request = request
        request.httpMethod = httpMethod.rawValue
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        let session = URLSession.shared
        
        let task = session.dataTask(with: request) { data, response, error in
            
            guard let data =  data, error == nil else {
                let error = ErrorModel(message: ErrorType.noInternetError.rawValue, title: Constants.kDefaultErrorMessage)
                completionHandler(.failure(error))
                return
            }
            
            do {
                let res = try JSONDecoder().decode(Token.self, from: data)
                completionHandler(.success(res))
                return
            } catch  {
                DispatchQueue.main.async {
                    let error = ErrorModel(message: ErrorType.otherError.rawValue, title: Constants.kDefaultErrorMessage)
                    completionHandler(.failure(error))
                }
                return
            }
        }
        task.resume()
    }
    
    
    static func findFalcone(httpMethod: HTTPMethod, request : URLRequest, params :[String:Any]? = nil, completionHandler:@escaping(Result<Falcone,ErrorModel>) -> Void){
        
        if !Reachability.isConnectedToInternet() {
            let errormodel = ErrorModel(message: ErrorType.noInternetError.rawValue,  title:Constants.kDefaultErrorMessage)
            completionHandler(.failure(errormodel))
        }
        
        var request = request
        request.httpMethod = httpMethod.rawValue
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        if let params = params {
            request.httpBody = try? JSONSerialization.data(withJSONObject: params, options: JSONSerialization.WritingOptions.prettyPrinted)
        }
        
        
        let session = URLSession.shared
        
        let task = session.dataTask(with: request) { data, response, error in
            
            guard let data =  data, error == nil else {
                let error = ErrorModel(message: ErrorType.noInternetError.rawValue, title: Constants.kDefaultErrorMessage)
                completionHandler(.failure(error))
                return
            }
            
            do {
                let res = try JSONDecoder().decode(Falcone.self, from: data)
                completionHandler(.success(res))
                return
            } catch  {
                DispatchQueue.main.async {
                    let error = ErrorModel(message: ErrorType.otherError.rawValue, title: Constants.kDefaultErrorMessage)
                    completionHandler(.failure(error))
                }
                return
            }
        }
        task.resume()
    }
    
}
