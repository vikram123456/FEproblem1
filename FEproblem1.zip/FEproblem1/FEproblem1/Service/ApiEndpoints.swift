//
//  ApiEndpoints.swift
//  FEproblem1
//
//  Created by Thakor Vikramji Kishanji on 10/05/22.
//

import Foundation

public enum ContentType : String{
    case key = "Content-Type", value = "application/json"
}
enum ApiEndpoints{
    
    static let baseURL = "https://findfalcone.herokuapp.com/"
 
    //MARK: --------- Methods---
    case planets
    case vehicles
    case token
    case find
    
    
    var stringValue: String{
        switch self {
        case .planets:
            return ApiEndpoints.baseURL + "planets"
        case .vehicles:
            return ApiEndpoints.baseURL + "vehicles"
        case .token:
            return ApiEndpoints.baseURL + "token"
        case .find:
            return ApiEndpoints.baseURL + "find"
        }
    }
    
    
    var url : URL{
        let urlString = stringValue.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        return URL(string: urlString!)!
    }
    
    var urlRequest : URLRequest{
        switch self {
        case .planets:
            var request = URLRequest(url: ApiEndpoints.planets.url)
            request.addValue(ContentType.value.rawValue, forHTTPHeaderField: ContentType.key.rawValue)
            return request
        case .vehicles:
            let request = URLRequest(url: ApiEndpoints.vehicles.url)
            return request
        case .token:
            let request = URLRequest(url: ApiEndpoints.token.url)
            return request
        case .find:
            let request = URLRequest(url:ApiEndpoints.find.url)
            return request
        }
    }
    
    
}
