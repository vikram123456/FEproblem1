//
//  DTHBoardModel.swift
//  TCPPaymentsKit
//
//  Created by Pratap Mondal on 05/03/20.
//  Copyright © 2020 Tata Digital Ltd. All rights reserved.
//

import Foundation
struct ErrorDetails: Error, Codable {
    let errorCode: String?
    let errorReason: String?
    let errorMessage: String?
    let titleMessage: String?
    let headerMessage: String?

    enum CodingKeys: String, CodingKey {
        case errorCode
        case errorReason
        case errorMessage
        case titleMessage
        case headerMessage
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        errorCode = try values.decodeIfPresent(String.self, forKey: .errorCode)
        errorReason = try values.decodeIfPresent(String.self, forKey: .errorReason)
        errorMessage = try values.decodeIfPresent(String.self, forKey: .errorMessage)
        titleMessage = try values.decodeIfPresent(String.self, forKey: .titleMessage)
        headerMessage = try values.decodeIfPresent(String.self, forKey: .headerMessage)
    }
}
