//
//  NetworkWrapperExtension.swift
//  FEproblem1
//
//  Created by Thakor Vikramji Kishanji on 10/05/22.
//

import Foundation

extension NetworkWrapper{
    
    static func getAllPlanets(completion:@escaping(Result<[Planet], ErrorModel>) -> Void){
        NetworkWrapper.connectForPlanets(httpMethod: .get, request: ApiEndpoints.planets.urlRequest) { result in
            completion(result)
        }
    }
    
    static func getAllVehicles(completion:@escaping(Result<[Vehicle], ErrorModel>) -> Void){
        NetworkWrapper.connectForVehicles(httpMethod: .get, request: ApiEndpoints.vehicles.urlRequest) { result in
            completion(result)
        }
    } 
    
    static func findToken(completion:@escaping(Result<Token, ErrorModel>) -> Void){
        NetworkWrapper.findToken(httpMethod: .post, request: ApiEndpoints.token.urlRequest) { result in
            completion(result)
        }
    }
    
    static func findFalcone(params: [String:Any]?, completion:@escaping(Result<Falcone, ErrorModel>) -> Void){
        NetworkWrapper.findFalcone(httpMethod: .post, request: ApiEndpoints.find.urlRequest, params: params) { result in
            completion(result)
        }
    }
}
