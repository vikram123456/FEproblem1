//
//  ViewController.swift
//  FEproblem1
//
//  Created by Thakor Vikramji Kishanji on 10/05/22.
//

import UIKit

class ViewController: UIViewController, UINavigationBarDelegate {
 
    @IBOutlet weak var tableviewMain: UITableView!
    @IBOutlet weak var tableviewDropDown: UITableView!
    @IBOutlet weak var viewOptions: UIView!
    
    var arrSections = ["Select","Select","Select","Select"]
    var arrSelectedPlanets = [String]()
    var arrSelectedVehicles = [[String:String]]()
    var arrPlanets = [Planet]()
    var arrVehicles = [Vehicle]()
    var nSelectedDestination = 0
    var isOpened = false
    
    var dictFinal  = [String:Any]()

    //MARK: View LifeCycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
       self.navigationController?.navigationBar.delegate = self
        self.fetchPlanets()
        self.fetchVehicles()
        self.findToken()
    }

    override func viewWillAppear(_ animated: Bool) {
        self.arrSelectedVehicles.removeAll()
        self.dictFinal.removeAll()
        arrSections = ["Select","Select","Select","Select"]
        isOpened = false
        tableviewMain.reloadData()
    }
    
    
    //MARK: Custom Action Methods
    @IBAction func buttonCancelClicked(_ sender: Any) {
        viewOptions.isHidden = true
    }
    
    @IBAction func buttonDoneClicked(_ sender: Any) {
        viewOptions.isHidden = true
    }
    
    @IBAction func buttonFindFalconClicked(_ sender: Any) {
        let arrTempVehicles = arrSelectedVehicles.compactMap { $0["vehicle"] }
        let arrTempPlanets = arrSections.filter { $0 != "Select"}
        dictFinal["planet_names"] = arrTempPlanets
        dictFinal["vehicle_names"] = arrTempVehicles
        if arrTempVehicles.count == 0 {
            Constants.showAlert("Please select any vehicle!")
            return
        }
        
        if arrTempPlanets.count == 0 {
            Constants.showAlert("Please select any planet to find falcone!")
            return
        }
        findFalcone()
     }

    
 
}

