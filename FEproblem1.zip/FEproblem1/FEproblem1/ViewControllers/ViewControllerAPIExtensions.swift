//
//  ViewControllerAPIExtensions.swift
//  FEproblem1
//
//  Created by Thakor Vikramji Kishanji on 16/05/22.
//

import Foundation



extension ViewController{
    
    // MARK: - Fetch Planets...
    func fetchPlanets() {
         NetworkWrapper.getAllPlanets {result in
             switch result{
             case .success(let res):
                 self.arrPlanets = res
                 DispatchQueue.main.async {
                     self.tableviewDropDown.reloadData()
                 }
             case .failure(let error):
                 Constants.showAlert(error.message)
                 break
              }
             
         }
    }

    // MARK: - Fetch Vehicles...
    func fetchVehicles() {
         NetworkWrapper.getAllVehicles {result in
             switch result{
             case .success(let res):
                 self.arrVehicles = res
                 DispatchQueue.main.async {
                     self.tableviewMain.reloadData()
                 }
             case .failure(let error):
                 Constants.showAlert(error.message)
                 break
              }
        }
    }
    
    // MARK: - Find Token...
    func findToken() {
        NetworkWrapper.findToken {result in
            switch result{
            case .success(let res):
                self.dictFinal["token"] = res.token
                  break
            case .failure(let error):
                Constants.showAlert(error.message)
                break
            }
       }
    }
    
    // MARK: - Find Falcone...
    func findFalcone() {
        NetworkWrapper.findFalcone(params: dictFinal) {result in
            switch result{
            case .success(let res):
                if res.status == Constants.kSuccess{
                    DispatchQueue.main.async {
                        let objResultViewController : ResultViewController = (self.storyboard?.instantiateViewController(withIdentifier: "ResultViewController") as? ResultViewController)!
                        objResultViewController.strPlanet = res.planet_name
                        self.navigationController?.pushViewController(objResultViewController, animated: true)
                     }
                }else{
                    DispatchQueue.main.async {
                        Constants.showAlert(Constants.kNoPlanets)
                    }
                }
                  break
            case .failure(let error):
                Constants.showAlert(error.message)
                break
            }
       }
    }
    
    
}
