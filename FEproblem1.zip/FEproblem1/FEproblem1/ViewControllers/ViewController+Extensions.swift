//
//  ViewController.swift
//  FEproblem1
//
//  Created by Thakor Vikramji Kishanji on 10/05/22.
//

import UIKit

extension ViewController{
    
    //MARK: Custom Action Methods
     @IBAction func buttonHeaderTapped(_ sender: Any) {
        let button : UIButton = sender as! UIButton
         nSelectedDestination = button.tag
         isOpened = true
         viewOptions.isHidden = false
         tableviewDropDown.reloadData()
    }
 
}
 
extension ViewController : UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        if tableView == tableviewDropDown{
            guard arrPlanets.count > 0 else {
                return
            }
            let objPlanet  = arrPlanets[indexPath.row]
            arrSections[nSelectedDestination] = objPlanet.name!
            viewOptions.isHidden = true
        }else {
            guard arrVehicles.count > 0 else {
                return
            }
            var objVehicle  = arrVehicles[indexPath.row]
            objVehicle.speed = 101
            arrVehicles[indexPath.row] = objVehicle
            
            for obj in arrSelectedVehicles{
                if obj["section"]! == String(nSelectedDestination){
                    arrSelectedVehicles = arrSelectedVehicles.filter { $0 != obj }
                }
            }
            arrSelectedVehicles.append(["section": String(nSelectedDestination),"vehicle":objVehicle.name!])
        }
        tableviewMain.reloadData()
     }
}



extension ViewController : UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if  tableView == self.tableviewDropDown {
            return arrPlanets.count
        }
        if nSelectedDestination == section && isOpened == true {
            return arrVehicles.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if  tableView == self.tableviewDropDown {
            let cell : PlanetCell = tableView.dequeueReusableCell(withIdentifier: "PlanetCell") as! PlanetCell
            let objPlanet = arrPlanets[indexPath.row]
            cell.setupPlanetCell(objPlanet: objPlanet)
            return cell
        }
        let cell : RadioCell = tableView.dequeueReusableCell(withIdentifier: "RadioCell") as! RadioCell
        let objVehicle = arrVehicles[indexPath.row]
        cell.setupRadioButtonCell(objVehicle: objVehicle, arrSelectedVehicles: arrSelectedVehicles, indexpath: indexPath)
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if  tableView == self.tableviewDropDown {
            return 1
        }
        return 4
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if  tableView == self.tableviewDropDown {
            return nil
        }
        let headerview = UIView(frame: CGRect(x: 10, y: 10, width: tableView.frame.size.width, height: 70))
        headerview.backgroundColor = Constants.kColorText
        
        let buttonHeader = UIButton(frame: headerview.frame)
        buttonHeader.frame = CGRect(x: 0, y: 0, width:  tableView.frame.size.width, height: 50)
        buttonHeader.setTitle(arrSections[section], for: .normal)
        buttonHeader.titleLabel?.font =  Constants.kFont
        buttonHeader.tag = section
        buttonHeader.layer.borderColor = UIColor.white.cgColor
        buttonHeader.layer.borderWidth =  0.5
        
         buttonHeader.addTarget(self, action: #selector(buttonHeaderTapped), for: .touchUpInside)
        let imageviewDrop = UIImageView(image: UIImage(named: "dropdown_icon"))
        imageviewDrop.frame =  CGRect(x: tableView.frame.size.width - 30, y: buttonHeader.center.y - 5, width:  15, height: 10)
        headerview.addSubview(imageviewDrop)
        headerview.addSubview(buttonHeader)
        return headerview
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if  tableView == self.tableviewDropDown {
            return 0
        }
        return 50
    }
 
}


