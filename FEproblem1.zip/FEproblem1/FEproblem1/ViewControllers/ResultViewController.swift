//
//  ResultViewController.swift
//  FEproblem1
//
//  Created by Thakor Vikramji Kishanji on 16/05/22.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var labelPlanet: UILabel!
    var strPlanet : String?
    
    //MARK: View LifeCycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    //MARK: Custom Methods
    func setupUI()  {
        self.navigationItem.hidesBackButton = true
        self.labelPlanet.text = "Planet found: " + (self.strPlanet ?? "")
    }

    @IBAction func buttonStartClicked(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
 
}
