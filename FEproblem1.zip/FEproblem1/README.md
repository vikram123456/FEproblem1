#  INTRODUCTION
-------------------
This project includes entire searching process for the planet. User can be able tp provide more and more Searching Criteria for searching any planet based on requirement.

 
#  REQUIREMENTS
-------------------
User can search planet by using multiple options but user must be able to understantd the scenario or search critera where the planet is residing.


#  INSTALLATION
-------------------
It can be able to get installed in different iPhone devices. 
There is no any single third party library has been used.


#  Author
-------------------
You can contact author Vikram K Thakor.
 


